// index.ts
import { SimuladorMercado } from './simulador';
import { Orden } from './orden';  

const simulador = new SimuladorMercado();

// Ejemplos de ordenes de compra y venta para cada empresa (X, Y, Z)
simulador.insertarOrdenCompra(new Orden('Empresa X', 100, 130, 'compra'));
simulador.insertarOrdenVenta(new Orden('Empresa X', 300, 85, 'venta'));

simulador.insertarOrdenCompra(new Orden('Empresa Y', 150, 120, 'compra'));
simulador.insertarOrdenVenta(new Orden('Empresa Y', 500, 105, 'venta'));

simulador.insertarOrdenCompra(new Orden('Empresa Z', 200, 110, 'compra'));
simulador.insertarOrdenVenta(new Orden('Empresa Z', 800, 100, 'venta'));


// Ejecucion
simulador.ejecutarSimulacion();
